# Spudnik Design System

Spudnik is a personal AI assistant project (school capstone for AI Fundamentals, codename **Tater**) built to replace Siri/Google Assistant with a local-first, sarcastic-genius voice assistant. This design system covers Spudnik's two current-phase surfaces: a **desktop-first PWA dashboard** ("Spudnik_Presence") and a **marketing landing page**.

Tater's personality: a "mentally unstable potato computer simulating a sarcastic 24-year-old tech genius who hasn't slept in three days" — JARVIS built by a broke college student, not a corporate assistant.

## Sources used

- GitHub repo: [SarahAyresSpudnik/Spudnik](https://github.com/SarahAyresSpudnik/Spudnik) — project charter, roadmap, and persona docs. Most source files (`backend/`, `persona/`) are stubs at this stage of the course project; explore the repo directly for the latest code.
- A Google Stitch export (`spudnik_about_tater` landing page, `spudnik_mission_control_presence_v2` dashboard, plus two `warm_terminal_diy` DESIGN.md briefs) supplied the only concrete visual/UI source — colors, type, spacing, and two full page mockups. These are AI-generated Stitch concepts commissioned by the project owner, not shipped production code; treat this design system as a faithful continuation of that direction, and check the repo for how (or whether) the real frontend has since diverged.
- `Timeline_Docs/Spudnik_roadmap.md` and `module_5/Charter.md` — product vision, platform priorities (desktop first), and tone for copy.

Explore these further yourself for a deeper build: the roadmap describes phone/car phases not yet reflected in any UI, and the persona markdown files (`persona/tater-*.md`) are currently empty placeholders worth filling in for real copywriting reference.

## Index

- `styles.css` — root stylesheet, import-only. Pulls in everything below.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `fonts.css`
- `base.css` — global reset/body defaults
- `components/` — reusable primitives, grouped `core/`, `forms/`, `navigation/`, `feedback/`
  - Button, Badge, Card, TerminalInput, Toggle, NavItem, StatusDot
- `ui_kits/landing/` — marketing site recreation (`index.html`, `LandingApp.jsx`)
- `ui_kits/dashboard/` — desktop PWA dashboard recreation (`index.html`, `DashboardApp.jsx`)
- `guidelines/` — foundation specimen cards (colors, type, spacing, brand, iconography)
- `assets/reference/` — the two original Stitch mockup screenshots, kept for comparison
- `SKILL.md` — portable skill file for using this system in Claude Code

## Intentional additions

No component library/Figma file defines an explicit inventory — the two Stitch mockups are the ground truth. The 7 components built (Button, Badge, Card, TerminalInput, Toggle, NavItem, StatusDot) are exactly what those two screens use, sized to the brand's current needs. Nothing was added beyond what's visible in the mockups.

## Content fundamentals

**Voice:** Tater speaks in first person about itself and refers to the user directly ("you") — but the *marketing copy* around it speaks as the builder, in first person singular ("I built this because…", "my unhinged diary entries"). Two registers:
- **System/Tater voice** — deadpan, sarcastic, mock-annoyed. "STATUS: ONLINE & ANNOYED." "I'm not saying I'm bored, but I just computed pi to the last digit twice." Uses fake log/terminal lines as jokes: `> WARNING: Caffeine levels low. Snark module engaged.`
- **Builder voice** (about/architecture sections) — plain, first-person, a little self-deprecating about scope: "Because sending my unhinged diary entries to a corporate server feels bad."

**Casing:** ALL-CAPS for system labels and status strings (`STATUS: NOMINAL`, `LINK ACTIVE`, `UNSTABLE`) — mimics hardware/terminal readouts. Sentence case for actual prose (descriptions, bios). Never title-case body copy.

**No emoji, ever.** Personality comes from text tone and terminal-style formatting (`>` prompts, log timestamps, `user@host:~$`), not iconography or emoji.

**Vibe:** scrappy DIY hardware lab, not corporate SaaS. Fake system logs and mock error states are a running bit ("Root Beer Emergency", "Snark module engaged"). Numbers/stats are used for flavor (latency, VRAM) not real dashboards — keep them plausible-sounding rather than exhaustive.

## Visual foundations

**Colors:** warm dark charcoal base (`#1A1714` background, `#252019` card surface, `#2D2926` raised) — no blue or purple anywhere. Burnt amber (`#E8874C`) is the primary/active accent. Sage-teal (`#8FB5A8`) is secondary/structural. Muted potato-brown (`#A87A52`) is decorative/tertiary. Olive-green (`#8A9A5B`) = success, rust-red (`#B24A3E`) = error/warning.

**Type:** dual-font system. JetBrains Mono for everything structural — headlines, labels, buttons, metadata, terminal/log text — often uppercase with slight letter-spacing to read like hardware serials. IBM Plex Sans for body copy, AI responses, and long-form description text, for legibility.

**Backgrounds:** flat, opaque, warm-dark. No photography-heavy hero, no full-bleed imagery required — the landing hero uses a soft radial amber glow behind the wordmark, not a photo. No repeating textures or patterns except a very subtle scanline/vignette treatment used once on the dashboard mockup (optional, skip by default — it reads as an easter egg, not a system-wide rule).

**Gradients:** none anywhere **except** the central "presence orb" — a radial gradient sphere (amber core fading to a dark rim) that represents Tater's live presence indicator. This is the one deliberate glow/gradient moment in the whole system; do not add gradients elsewhere.

**Animation:** minimal and functional, never decorative-bouncy. The presence orb has a slow (4s) breathing scale pulse. Hover states are instant fades (~150ms ease) between fill and outline, not color-darkening. No easing flourishes, no page-transition animation evidenced.

**Hover states:** buttons invert — a solid-fill button becomes transparent-with-colored-text on hover (not darker/lighter of the same fill). Cards get a colored border on hover (e.g. amber/sage) rather than a shadow or lift. Links underline or shift to a lighter tint.

**Press/active states:** left-nav active item gets a 2px amber left border + a raised background tint, not a filled pill. No visible "pressed/shrink" state was evidenced in the source — keep press states subtle (border color shift only).

**Borders vs shadows:** **no drop shadows anywhere.** Depth comes entirely from tonal layering (progressively lighter charcoal surfaces) plus 1px hairline borders (`--border: #3A342C`). Active/focused elements get a border-color shift to amber or sage, never a shadow or glow ring (the one exception is the small `box-shadow` "glow" on status dots/orb, used sparingly).

**Corner radii:** small (4px) for badges/chips, 8px for buttons/inputs, 16px for cards. Nothing pill-shaped except the badge could round further but the source keeps even chips at 4px — avoid rounded-pill anywhere, it reads as too corporate-SaaS for this brand.

**Cards:** `--surface-card` background, 1px `--border` hairline, 16px radius, no shadow. Header (if present) separated by its own hairline rule, not a colored bar. Never a colored left-border-only card treatment.

**Transparency/blur:** essentially none. Surfaces are always opaque and solid — explicitly no backdrop-filter/glassmorphism per the source DESIGN docs. The one soft/blurred element is the hero's ambient amber glow behind the wordmark.

**Imagery color vibe:** the only real imagery evidenced (three "Node Instance" character portraits — Tater/Rouge/Mage) is desaturated/grayscale by default, going full-color only on hover — a deliberate "this is a low-power sensor feed" affectation. Any future photography should follow this warm, slightly desaturated, low-glare treatment — not clean bright corporate photography.

**Layout rules:** desktop-first, asymmetric grid (roughly 7/5 or 12-col with uneven column spans) rather than perfectly symmetric dashboards — utility panels sit in a heavier right-hand column. Content is left-aligned, not centered, except the landing hero.

## Iconography

The Stitch mockups use **Material Symbols Outlined** (Google's icon font) throughout — loaded via Google Fonts CDN, referenced as ligature names (`memory`, `terminal`, `psychology`, `database`, `security`, `keyboard_return`, `visibility_off`, `list_alt`, `help_outline`, `groups`, `architecture`). This is a CDN icon font, not a custom Spudnik icon set — no bundled SVG icon library was found in the source. Icons are rendered outline-only (never filled), tinted sage-teal for structural/decorative use or inherit the surrounding text color for inline labels. No emoji or unicode-character icons are used anywhere. Small solid circles (not icons) are used for status/health indicators (olive = active, rust = error). If a bespoke Spudnik icon set is ever produced, document its stroke weight and grid here and prefer it over Material Symbols.

## Caveats — please help me iterate

- **No real logo exists.** I did not find a Spudnik logotype or mark anywhere in the repo or the Stitch export — the wordmark is currently plain JetBrains Mono type. If you have a logo, drop it in `assets/` and I'll wire it into the nav, footer, and thumbnail.
- **Fonts load from the Google Fonts CDN** (`tokens/fonts.css`), not bundled local binaries — both JetBrains Mono and IBM Plex Sans are open Google Fonts, so this should be safe and fully in-spec; flag if you'd prefer self-hosted font files instead.
- **The GitHub repo's actual application code is almost entirely empty stub files** (`backend/*.py`, `persona/*.md` are 1-byte placeholders) — this design system is built from the Stitch mockups and the roadmap docs, not from a working frontend. As the real Flask/PWA frontend gets built, re-check this system against it and let me know what's drifted.
- **The three "Node Instance" character portraits** (Tater/Rouge/Mage) in the landing page were AI-generated illustrations hosted on a temporary Google CDN URL inside the Stitch export — I could not durably copy them, so the landing kit uses fillable image-slot placeholders in their place. Real character art would make that section much stronger.
- I'd love your take on whether the dashboard's sidebar sections (Memory, Protocols, Hardware) should get their own mocked screens next — happy to build those out.
